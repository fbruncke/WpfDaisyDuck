﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfDaisyDuck
{
    public delegate void SpeakDelegate(string speak);

    class Duck
    {
        private string name;
        public event SpeakDelegate speakDel;

        Duck(String name)
        {

        }

        public void Listening(string sound)
        {
            //Print what the Duck is hearing
        }

        public void Speak()
        {
            //Print what the Duck is saying
        }
    }
}
